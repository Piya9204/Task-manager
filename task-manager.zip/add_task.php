<?php
require 'db.php';
$data = json_decode(file_get_contents("php://input"), true);

$title = $data['title'];
$due_date = $data['due_date'];
$category = $data['category'];
$priority = $data['priority'];

$sql = "INSERT INTO tasks (title, due_date, category, priority, status) VALUES (?, ?, ?, ?, 'pending')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $title, $due_date, $category, $priority);
$stmt->execute();
echo json_encode(["success" => true]);
?>