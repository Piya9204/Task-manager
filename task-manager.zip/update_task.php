<?php
require 'db.php';
$data = json_decode(file_get_contents("php://input"), true);

$id = $data['id'];

$sql = "UPDATE tasks SET status='done' WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

echo json_encode(["success" => true]);
?>