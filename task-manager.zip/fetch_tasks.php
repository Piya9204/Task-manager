<?php
require 'db.php';

$category = $_GET['category'] ?? '';
$priority = $_GET['priority'] ?? '';

$query = "SELECT * FROM tasks WHERE 1=1";

if ($category) {
    $query .= " AND category='$category'";
}
if ($priority) {
    $query .= " AND priority='$priority'";
}

$result = $conn->query($query);
$tasks = [];

while ($row = $result->fetch_assoc()) {
    $tasks[] = $row;
}

echo json_encode($tasks);
?>