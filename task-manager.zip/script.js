document.addEventListener("DOMContentLoaded", () => {
  fetchTasks();

  document.getElementById("taskForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const title = document.getElementById("title").value;
    const due_date = document.getElementById("due_date").value;
    const category = document.getElementById("category").value;
    const priority = document.getElementById("priority").value;

    await fetch("add_task.php", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ title, due_date, category, priority })
    });

    e.target.reset();
    fetchTasks();
  });

  document.getElementById("filterCategory").addEventListener("change", fetchTasks);
  document.getElementById("filterPriority").addEventListener("change", fetchTasks);
});

async function fetchTasks() {
  const category = document.getElementById("filterCategory").value;
  const priority = document.getElementById("filterPriority").value;

  const res = await fetch(`fetch_tasks.php?category=${category}&priority=${priority}`);
  const tasks = await res.json();

  const list = document.getElementById("taskList");
  list.innerHTML = "";

  tasks.forEach((task) => {
    const li = document.createElement("li");
    li.className = task.status === "done" ? "done" : "";

    li.innerHTML = `
      <strong>${task.title}</strong> [${task.category}] - ${task.priority}
      <br><small>Due: ${task.due_date}</small>
      <br>
      <button onclick="markDone(${task.id})">✔</button>
      <button onclick="deleteTask(${task.id})">🗑</button>
    `;
    list.appendChild(li);
  });
}

async function markDone(id) {
  await fetch("update_task.php", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ id })
  });
  fetchTasks();
}

async function deleteTask(id) {
  await fetch("delete_task.php", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ id })
  });
  fetchTasks();
}